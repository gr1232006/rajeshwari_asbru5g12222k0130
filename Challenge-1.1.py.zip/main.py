number=int(input("please enter any number :"))
fact=1
for i in range (1, number +1):
  fact=fact*i
  print ("the factorial of %d =%d"%(number,fact))